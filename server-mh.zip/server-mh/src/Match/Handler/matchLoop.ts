import { GameFlowManager } from "./MatchPhases/GameFlowManager";
import { MatchContext } from "./Models/MatchContex";
import { MatchState as ludoMatchstate } from "./Models/MatchState"



const gameFlowManager = new GameFlowManager();

export const matchLoop = function (
	ctx: nkruntime.Context,
	logger: nkruntime.Logger,
	nk: nkruntime.Nakama,
	dispatcher: nkruntime.MatchDispatcher,
	tick: number,
	state: nkruntime.MatchState,
	messages: nkruntime.MatchMessage[]
): { state: nkruntime.MatchState } | null {
	const matchState = state as ludoMatchstate;
	logger.debug('Lobby match loop executed');
	if (matchState.matchEnd) {
		return null;
	}
	const contex:MatchContext=new MatchContext(matchState,logger,dispatcher,nk,tick,messages);
	gameFlowManager.Update(contex);
	
	return {
		state: matchState
	};
}