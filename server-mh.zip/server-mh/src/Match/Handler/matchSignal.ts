export const matchSignal: nkruntime.MatchSignalFunction =
(
    ctx,
    logger,
    nk,
    dispatcher,
    tick,
    state,
    data
) => {

    return {
        state: state,
        data: data
    };
};