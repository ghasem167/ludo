import { matchInit } from "./Match/Handler/matchInit";
import { matchJoinAttempt } from "./Match/Handler/matchJoinAttempt";
import { matchJoin } from "./Match/Handler/matchJoin";
import { matchLeave } from "./Match/Handler/matchLeave";
import { matchLoop } from "./Match/Handler/matchLoop";
import { matchTerminate } from "./Match/Handler/matchTerminate";
import { matchSignal } from "./Match/Handler/matchSignal";
import { MatchConfig } from "./Match/Handler/Models/MatchConfig";
import { GameMode, TeamMode } from "./Match/Handler/Enums";


let InitModule: nkruntime.InitModule = function (
    ctx,
    logger,
    nk,
    initializer
) {
    logger.info("Module loading pre registermatch");
    // =========================
    // MATCH REGISTRATION
    // =========================
    initializer.registerMatch("ludo", {
        matchInit,
        matchJoinAttempt,
        matchJoin,
        matchLeave,
        matchLoop,
        matchTerminate,
        matchSignal
    });
    logger.info("Module loaded pre matchmakermatched");
    // =========================
    // MATCHMAKER (ADD THIS)
    // =========================
    initializer.registerMatchmakerMatched(function (
        ctx,
        logger,
        nk,
        matches
    ) {
        const m = matches[0];

        const config: MatchConfig = {
            mode: Number(m.properties["gameMode"]) as GameMode,
            team: Number(m.properties["teamMode"]) as TeamMode,


        };

        return CreateLudoMatch(
            nk,
            config,
            matches.map(m => m.presence)
        );
    });

    logger.info("Module loaded");
};
(globalThis as any).InitModule = InitModule;




function CreateLudoMatch(
    nk: nkruntime.Nakama,
    config: MatchConfig,
    presences: nkruntime.Presence[]
): string {

    return nk.matchCreate("ludo", {
        config: JSON.stringify(config),
        initialPresences: JSON.stringify(presences)
    });
}